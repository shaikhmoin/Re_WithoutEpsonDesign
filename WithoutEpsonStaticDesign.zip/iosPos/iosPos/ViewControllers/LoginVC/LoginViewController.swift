//
//  LoginViewController.swift
//  iosPos
//
//  Created by resolutesolutions on 05/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit
import Alamofire

class LoginViewController: UIViewController {
    
    @IBOutlet weak var btnStar1: RSButton!
    @IBOutlet weak var btnStar2: RSButton!
    @IBOutlet weak var btnStar3: RSButton!
    @IBOutlet weak var btnStar4: RSButton!
    
    var count : Int = 0
    var strPin : String = ""
    
    //MARK:- Life cycle view
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- Button Pin Selection Click
    @IBAction func btnPinSelection(_ sender: UIButton) {
        
        if count < 4 {
            
            if (count == 0) {
                btnStar1.setTitle("*", for: .normal)
            } else if (count == 1) {
                btnStar2.setTitle("*", for: .normal)
            } else if (count == 2) {
                btnStar3.setTitle("*", for: .normal)
            } else {
                btnStar4.setTitle("*", for: .normal)
            }
            
            if strPin == "" {
                strPin = (sender.titleLabel?.text)!
                print(strPin)
            } else {
                
                strPin = strPin + (sender.titleLabel?.text)!
                print(strPin)
            }
            count = count + 1
        }
    }
    
    //MARK:- Button login press Click
    @IBAction func btnLognPress(_ sender: Any) {
        
        if strPin == "" {
            RSAlertUtils.displayAlertWithMessage("Please enter ein")
        } else if strPin.characters.count != 4 {
            RSAlertUtils.displayAlertWithMessage("Please enter 4 digit of Pin")
        } else {
            //self.serviceCallForLogin()
            self.serviceCallForLogin2()
        }
    }
    
    //MARK:- Button Clear Click
    @IBAction func btnClearPress(_ sender: Any) {
        
        // Clear Selected Digits
        if (count != 0) {
            count = count - 1
            if (count == 3) {
                btnStar4.setTitle("", for: .normal)
            }
            else if (count == 2) {
                btnStar3.setTitle("", for: .normal)
            }
            else if (count == 1) {
                btnStar2.setTitle("", for: .normal)
            }
            else {
                btnStar1.setTitle("", for: .normal)
            }
            
            strPin.remove(at: strPin.index(before: strPin.endIndex))
            print(strPin)
        }
    }
    
    //MARK:- Service Call For Login
    func serviceCallForLogin() {
        if IS_INTERNET_AVAILABLE() {
            
            var strUrl : String = CONSTANTS.APINAME.Login
            print("URL",strUrl)
            
            strUrl = CONSTANTS.BASE_URL.mainUrl + strUrl
            //print("\"\(strUrl)\"")
            
            let url = URL(string: strUrl)!
            var request = URLRequest(url: url)
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            request.httpMethod = "POST"
            let postString = "Procedure=TabOrder_Login&Json=[{PIN:" + strPin + "}]"
            request.httpBody = postString.data(using: .utf8)
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {                                                 // check for fundamental networking error
                    RSAlertUtils.displayAlertWithMessage(error as! String)
                    return
                }
                
                DispatchQueue.main.async {
                    
                    do {
                        
                        // Convert JSON from NSData to AnyObject
                        let jsonData = try JSONSerialization.jsonObject(with: data, options: []) as! [String:AnyObject]
                        print(jsonData)
                        
                        //Check Array Exits Or Not
                        if (ResolutePOS.checkArray(dict: jsonData, key: "Table")) {
                            
                            let arrTable : [AnyObject] = jsonData["Table"] as! [AnyObject]
                            print(arrTable)
                            
                            for i in 0...arrTable.count - 1 {
                                let dictTable : [String:AnyObject] = arrTable[i] as! [String:AnyObject]
                                print(dictTable)
                                
                                //Check String Exits Or Not
                                let strServer : String = ResolutePOS.object_forKeyWithValidationForClass_String(dict: dictTable, key: "Server")
                                print(strServer)
                                
                                let strUserID : String = ResolutePOS.object_forKeyWithValidationForClass_String(dict: dictTable, key: "UserID")
                                UserDefaults.standard.set(strUserID, forKey: CONSTANTS.USERID)
                                print(strUserID)
                                print(ResolutePOS.getUserID())
                                APPDELEGATE.openDasboardPage()
                            }
                        }
                    }
                    catch {
                        RSAlertUtils.displayAlertWithMessage("Something went wrong please try again")
                    }
                    
                }
            }
            task.resume()
        }
        else
        {
            RSAlertUtils.displayNoInternetMessage()
        }
    }
    
    //MARK: SERVICE CALL FOR LOGIN
    func serviceCallForLogin2() {
        if IS_INTERNET_AVAILABLE() {
            
            let strUrl : String = CONSTANTS.APINAME.Login
            print("URL",strUrl)
            
            let headers: HTTPHeaders = [:]
            
            //Pin for parameter value
            strPin = ("[{PIN:\(strPin)}]")
            
            //PinID And Loc ID declaration
            let PinID = ("{PinID:\(5)}")
            let locationID = ("{LocID:\(5)}")
            
            //PinID And Loc ID for combine values like dict
            var name = ""
            name.append(PinID + ",")
            name.append(locationID)
            
            //Append PinID And Loc Id into Array like [{PinID:5},{LocID:5}]
            var arrVal : [AnyObject] = [AnyObject]()
            arrVal.append(name as AnyObject)
            print(arrVal)
            
            var parameter : [String:Any] = [:]
            parameter["Procedure"] = "TabOrder_Login"
            parameter["Json"] = strPin
            print("PARAM",parameter)
            
            ServiceManager.sharedManager.postResponseWithHeader(strUrl, params: parameter, headers: headers, Loader: false) { (result) in
                print("RESPONSE", result)
                
                let resposeDict : [String : AnyObject] = result as! [String: AnyObject]
                print(resposeDict)
                self.strPin = ""
                
                //Check Table Array Exits Or Not From resposeDict
                if (ResolutePOS.checkArray(dict: resposeDict, key: "Table")) {
                    
                    let arrTable : [AnyObject] = resposeDict["Table"] as! [AnyObject]
                    print(arrTable)
                    
                    for i in 0...arrTable.count - 1 {
                        let dictTable : [String:AnyObject] = arrTable[i] as! [String:AnyObject]
                        print(dictTable)
                        
                        //Check String Exits Or Not From Dict Table
                        let strServer : String = ResolutePOS.object_forKeyWithValidationForClass_String(dict: dictTable, key: "Server")
                        print(strServer)
                        
                        let strUserID : String = ResolutePOS.object_forKeyWithValidationForClass_String(dict: dictTable, key: "UserID")
                        UserDefaults.standard.set(strUserID, forKey: CONSTANTS.USERID)
                        print(strUserID)
                        
                        print(ResolutePOS.getUserID())
                        APPDELEGATE.openDasboardPage()
                    }
                }
                
                //                if code == "200" {
                //
                //
                //
                //                }
                //                else {
                //                    //PIAlertUtils.displayAlertWithMessage(message)
                //                }
            }
        }
        else
        {
            //PIAlertUtils.displayNoInternetMessage()
        }
    }
}
