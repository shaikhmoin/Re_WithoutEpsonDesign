//
//  DashboardVC.swift
//  iosPos
//
//  Created by resolutesolutions on 06/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

class DashboardVC: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,UITableViewDataSource,UITableViewDelegate {
    
    //Button Outlets
    @IBOutlet weak var btnBookOrder: RSDashboardButton!
    @IBOutlet weak var btnOpenItem: RSDashboardButton!
    @IBOutlet weak var btnViewOrder: RSDashboardButton!
    
    @IBOutlet weak var btnAllCategory: RSDashboardButton!
    @IBOutlet weak var btnLoyaltyPoints: RSDashboardButton!
    @IBOutlet weak var btnCustomerVisit: RSDashboardButton!
    @IBOutlet weak var btnSearchItem: RSDashboardButton!
    
    @IBOutlet weak var btnItemReturn: RSDashboardButton!
    @IBOutlet weak var btnOrderAssign: RSDashboardButton!
    @IBOutlet weak var btnPayment: RSDashboardButton!
    
    @IBOutlet weak var btnHeldOrders: RSDashboardButton!
    @IBOutlet weak var btnOngoingOrders: RSDashboardButton!
    @IBOutlet weak var btnNewOrder: RSDashboardButton!
    
    //TblView And Cltn View Outlets
    @IBOutlet weak var cltnItemList: UICollectionView!
    @IBOutlet weak var tblCategoryList: UITableView!
    @IBOutlet weak var tblCartList: UITableView!
    @IBOutlet weak var tblModifierList: UITableView!
    
    //Uiview Outlets
    @IBOutlet var viewModifier: UIView!
    @IBOutlet weak var viewSubmodifier: UIView!
    @IBOutlet weak var viewSubmodifierList: UIView!
    @IBOutlet weak var viewMemo: UIView!
    var dimView:UIView?
    
    //Modifier/Memo Popup Outlets
    @IBOutlet weak var btnAddModifier: UIButton!
    @IBOutlet weak var btnAddMemo: UIButton!
    @IBOutlet weak var btnModifierQtyTitle: RSCartQtyTitleBolButton!
    
    var strCartQty : Int = 1
    
    var arr = ["Brewery Bar","Zuppa Soup","Cup Cakes","Healthy Wraps","Swiss Pleasure","Luxury Cake","Regular Cakes","Exotic Pastry ","Fresh Juice","Combo Platter","Cold Drinks","Dry Cakes","Pani Puri","Biryani","Sandwiches","Burger"]
    var arrModifier = ["Extra Cheez","Spicy","less spicy","very Hot","Extra Chocklate"]
    var arrImage = ["one","two","three","four","five","six","seven","eight","nine","one","two","three","four","five","six","seven","eight","nine"]
    
    //MARK:- View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        btnAddMemo.tintColor = UIColor.black
        
        //Tableview Cell XIB Load
        self.tblCategoryList.register(UINib(nibName: "CategoryListTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: CONSTANTS.ID_CATEGORY_LIST_TABLE_CELL)
        self.tblCartList.register(UINib(nibName: "CartListTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: CONSTANTS.ID_CART_LIST_TABLE_CELL)
        self.tblModifierList.register(UINib.init(nibName: "CategoryListTableViewCell", bundle: nil), forCellReuseIdentifier: CONSTANTS.ID_CATEGORY_LIST_TABLE_CELL)
        
        //CollectionView Cell XIB Load
        self.cltnItemList.register(UINib(nibName:"ItemListCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: CONSTANTS.ID_ITEM_LIST_COLLECTION_CELL_WITH_IMAGE)
        self.cltnItemList.register(UINib(nibName:"ItemListWIthLableCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: CONSTANTS.ID_ITEM_LIST_COLLECTION_CELL_WITH_LABLE)
        
        self.addPropertyPopupFunction()
        
        //Dynamic cell height
        tblCategoryList.rowHeight = UITableViewAutomaticDimension
        tblCategoryList.estimatedRowHeight = 80
        tblModifierList.rowHeight = UITableViewAutomaticDimension
        tblModifierList.estimatedRowHeight = 80
        
        //Hide footer seperator
        tblCategoryList.tableFooterView = UIView()
        tblModifierList.tableFooterView = UIView()
        
        //Cetegory Table 0 row selected by default
        let indexPath = IndexPath(row: 0, section: 0)
        tblCategoryList.selectRow(at: indexPath, animated: true, scrollPosition: .bottom)
        tblCategoryList.delegate?.tableView!(tblCategoryList, didSelectRowAt: indexPath)
        
        //Modifier Table 0 row selected by default
        let indexPathForModifier = IndexPath(row: 0, section: 0)
        tblModifierList.selectRow(at: indexPathForModifier, animated: true, scrollPosition: .bottom)
        tblModifierList.delegate?.tableView!(tblModifierList, didSelectRowAt: indexPathForModifier)
    }
    
    //MARK:- UIView Round Effect (Autolayout have this solution)
    override func viewWillLayoutSubviews() {
        btnAddModifier.roundedButton()
        //btnAddMemo.roundedButton()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        //        let touch: UITouch? = touches.first
        //        if touch?.view != viewModifier && touch?.view != viewSubmodifier && touch?.view != viewSubmodifierList && touch?.view != viewMemo {
        //            self.popUpHide(popupView: viewModifier)
        //        }
    }
    
    //MARK:- Status bar hidden Method
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- Collection View Datasource Methods
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrImage.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        //With Image Cell
        let itemCell = cltnItemList.dequeueReusableCell(withReuseIdentifier: CONSTANTS.ID_ITEM_LIST_COLLECTION_CELL_WITH_IMAGE, for: indexPath) as! ItemListCollectionViewCell
        
        itemCell.imgProduct.image = UIImage(named: arrImage[indexPath.item])
        
        return itemCell
        
        //Without Image Cell
        //        let itemCell = cltnItemList.dequeueReusableCell(withReuseIdentifier: CONSTANTS.ID_ITEM_LIST_COLLECTION_CELL_WITH_LABLE, for: indexPath) as! ItemListWIthLableCollectionViewCell
        //
        //        itemCell.applyShadowDefault()
        //        itemCell.viewItemList.applyShadowDefault()
        //
        //        return itemCell
    }
    
    //MARK:- Collection View Delegate Methods
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Hi")
    }
    
    //MARK: - Collection View DelegateFlowLayout Method
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = collectionView.frame.size.width
        
        if width < 820.0 {
            return CGSize(width: (width/4) - 20, height:140)
        } else {
            return CGSize(width: (width/4) - 20, height:180)
        }
    }
    
    //MARK:- Table View Datasource Methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == tblCategoryList {
            return arr.count
        } else if tableView == tblCartList {
            return arr.count
        } else if tableView == tblModifierList  {
            return arrModifier.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tblCategoryList {
            let categoryListCell = tblCategoryList.dequeueReusableCell(withIdentifier: CONSTANTS.ID_CATEGORY_LIST_TABLE_CELL, for: indexPath) as! CategoryListTableViewCell
            
            let data = arr[indexPath.row]
            categoryListCell.lblName.text = data
            
            return categoryListCell
            
        } else if tableView == tblCartList {
            let cartItemListCell = tblCartList.dequeueReusableCell(withIdentifier: CONSTANTS.ID_CART_LIST_TABLE_CELL, for: indexPath) as! CartListTableViewCell
            
            print(arr)
            
            cartItemListCell.lblItemName.text = arr[indexPath.row]
            cartItemListCell.btnModifier.tag = indexPath.row
            cartItemListCell.btnDeleteCart.tag = indexPath.row
            cartItemListCell.btnPlusQty.tag = indexPath.row
            cartItemListCell.btnMinusQty.tag = indexPath.row
            
            cartItemListCell.btnModifier.addTarget(self, action: #selector(self.btnOpenModifierClick), for: .touchUpInside)
            cartItemListCell.btnDeleteCart.addTarget(self, action: #selector(self.btnDeleteCartClick), for: .touchUpInside)
            cartItemListCell.btnPlusQty.addTarget(self, action: #selector(self.btnAddQtyClick), for: .touchUpInside)
            cartItemListCell.btnMinusQty.addTarget(self, action: #selector(self.btnMinusQtyClick), for: .touchUpInside)
            
            return cartItemListCell
        }
            
        else if tableView == tblModifierList {
            let categoryListCell = tblCategoryList.dequeueReusableCell(withIdentifier: CONSTANTS.ID_CATEGORY_LIST_TABLE_CELL, for: indexPath) as! CategoryListTableViewCell
            
            let data = arrModifier[indexPath.row]
            categoryListCell.lblName.text = data
            
            return categoryListCell
        }
        return UITableViewCell()
    }
    
    //MARK:- Table View Delegate Methods
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == tblCategoryList {
            print("Category Table List")
        } else if tableView == tblCartList {
            
            //            tableView.deselectRow(at: indexPath, animated: true)
            //            self.arr.remove(at: indexPath.row)
            //            tableView.reloadData()
            
        } else if tableView == tblModifierList  {
            print("Modifier List")
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if tableView == tblCategoryList {
            return UITableViewAutomaticDimension
            
        } else if tableView == tblCartList {
            
            let strDescribtion: String = "Regular Size,Extra cheeze"
            let strCount = strDescribtion.count
            
            var width: CGFloat = 0
            width = UIScreen.main.bounds.width - 350
            let size: CGSize = CGSize(width: width, height: 1000.0)
            
            var strDescriptionHeight:CGFloat = ResolutePOS.HeightforLabel(text: strDescribtion, font: UIFont.systemFont(ofSize: 18.0), maxSize: size)
            
            if strCount > 60 {
                strDescriptionHeight = 80
            } else {
                strDescriptionHeight = 60
            }
            return 130 - 60 + strDescriptionHeight
        }
            
        else if tableView == tblModifierList {
            return UITableViewAutomaticDimension
        }
        
        return 0.0
    }
    
    //MARK:- In CartList Button Add Quantity Click
    @objc func btnAddQtyClick(sender:UIButton) {
        print(sender.tag)
        
        // Get cell oultlets
        let position: CGPoint = sender.convert(.zero, to: tblCartList)
        let indexPath = self.tblCartList.indexPathForRow(at: position)
        let cell: CartListTableViewCell = tblCartList.cellForRow(at: indexPath!) as!
        CartListTableViewCell
        
        //Get Selected button title text
        let selectedBtnTitle = cell.btnQtyTitle.title(for: .normal)
        print(selectedBtnTitle ?? "Default")
        
        strCartQty = Int(selectedBtnTitle!)!
        
        //Qty Increment
        strCartQty = strCartQty + 1
        cell.btnQtyTitle.setTitle(String(strCartQty), for: .normal)
    }
    
    //MARK:- In CartList Button Minus Quantity Click
    @objc func btnMinusQtyClick(sender:UIButton) {
        print(sender.tag)
        
        // Get cell oultlets
        let position: CGPoint = sender.convert(.zero, to: tblCartList)
        let indexPath = self.tblCartList.indexPathForRow(at: position)
        let cell: CartListTableViewCell = tblCartList.cellForRow(at: indexPath!) as!
        CartListTableViewCell
        
        //Get Selected button title text
        let selectedBtnTitle = cell.btnQtyTitle.title(for: .normal)
        print(selectedBtnTitle ?? "Default")
        
        strCartQty = Int(selectedBtnTitle!)!
        print(strCartQty)
        
        //Qty Decrement
        if (strCartQty != 1) {
            strCartQty = strCartQty - 1
            cell.btnQtyTitle.setTitle(String(strCartQty), for: .normal)
        }
    }
    
    //MARK:- In Modifier Button Plus Quantity Click
    @IBAction func btnAddModifierQtyClick(_ sender: Any) {
        
        //Get Selected button title text
        let selectedBtnTitle = btnModifierQtyTitle.title(for: .normal)
        print(selectedBtnTitle ?? "Default")
        
        strCartQty = Int(selectedBtnTitle!)!
        
        //Qty Increment
        strCartQty = strCartQty + 1
        btnModifierQtyTitle.setTitle(String(strCartQty), for: .normal)
    }
    
    //MARK:- In Modifier Button Minus Quantity Click
    @IBAction func btnMinusModifierQtyClick(_ sender: Any) {
        
        //Get Selected button title text
        let selectedBtnTitle = btnModifierQtyTitle.title(for: .normal)
        print(selectedBtnTitle ?? "Default")
        
        strCartQty = Int(selectedBtnTitle!)!
        print(strCartQty)
        
        //Qty Decrement
        if (strCartQty != 1) {
            strCartQty = strCartQty - 1
            btnModifierQtyTitle.setTitle(String(strCartQty), for: .normal)
        }
    }
    
    //MARK:- Button Open Modifier Popup
    @objc func btnOpenModifierClick(sender:UIButton) {
        print(sender.tag)
        
        self.modifierClickAnimation()
        self.popUpShow(popupView: viewModifier)
    }
    
    //MARK:- Button Delete Selected Cart Record
    @objc func btnDeleteCartClick(sender:UIButton) {
        print(sender.tag)
        
        print(arr)
        self.arr.remove(at: sender.tag)
        tblCartList.reloadData()
        
        //        tableView.deselectRow(at: indexPath, animated: true)
        //        self.arr.remove(at: indexPath.row)
        //        tableView.reloadData()
    }
    
    //MARK:- Button Close Modifier Popup
    @IBAction func btnCloseModifierClick(_ sender: Any) {
        self.popUpHide(popupView: viewModifier)
    }
    
    //MARK:- Button Add Modifier Click
    @IBAction func btnAddModifierClick(_ sender: Any) {
        self.modifierClickAnimation()
    }
    
    //MARK:- Button Add Memo Click
    @IBAction func btnAddMemoClick(_ sender: Any) {
        self.memoClickAnimation()
    }
    
    // MARK:- UIPopup methods
    func addPropertyPopupFunction()  {
        
        self.view.addSubview(viewModifier)
        self.viewModifier.alpha = 0.0
        
        var popupWidth: Int = 0
        var popupHeight: Int = 0
        
        popupWidth = 700
        popupHeight = 450
        
        var x:Int = Int(UIScreen.main.bounds.width)
        var y:Int = Int(UIScreen.main.bounds.height)
        
        x =  (x - Int(popupWidth)) / 2
        y = (y - Int(popupHeight)) / 2
        
        viewModifier.frame = CGRect(x: CGFloat(x), y: CGFloat(y), width: CGFloat(popupWidth), height: CGFloat(popupHeight))
        
        viewModifier.layoutIfNeeded()
        self.view.addSubview(viewModifier)
    }
    
    func popUpShow(popupView :UIView) {
        
        dimView = UIView()
        dimView?.frame = self.view.frame
        dimView?.backgroundColor = UIColor.white
        dimView?.alpha = 0.5
        
        var x:Int = Int(UIScreen.main.bounds.width)
        var y:Int = Int(UIScreen.main.bounds.height)
        
        x =  (x - Int(popupView.frame.width)) / 2
        y = (y - Int(popupView.frame.height)) / 2
        
        popupView.frame = CGRect(x: CGFloat(x), y: CGFloat(y), width: popupView.frame.width, height: popupView.frame.height)
        popupView.layer.cornerRadius = 5.0
        popupView.layer.masksToBounds = true
        
        self.view.addSubview(dimView!)
        self.view.bringSubview(toFront: popupView)
        popupView.alpha = 1.0
    }
    
    func popUpHide(popupView :UIView) {
        dimView?.removeFromSuperview()
        popupView.alpha = 0.0
    }
    
    //MARK:- Design Helper Method
    func modifierClickAnimation() {
        btnAddMemo.roundedButtonRollback()
        btnAddModifier.roundedButton()
        btnAddMemo.backgroundColor = UIColor.clear
        btnAddModifier.backgroundColor = UIColor(hexString: "E1E1E1")
        btnAddMemo.tintColor = UIColor.black
        btnAddModifier.tintColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_DARK_COLOR)
        viewMemo.isHidden = true
        viewSubmodifier.isHidden = false
    }
    
    func memoClickAnimation() {
        btnAddModifier.roundedButtonRollback()
        btnAddMemo.roundedButton()
        btnAddModifier.backgroundColor = UIColor.clear
        btnAddMemo.backgroundColor = UIColor(hexString: "E1E1E1")
        btnAddModifier.tintColor = UIColor.black
        btnAddMemo.tintColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_DARK_COLOR)
        viewMemo.isHidden = false
        viewSubmodifier.isHidden = true
    }
}

