//
//  ItemListWIthLableCollectionViewCell.swift
//  iosPos
//
//  Created by Akash on 6/23/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

class ItemListWIthLableCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var viewItemList: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
}
