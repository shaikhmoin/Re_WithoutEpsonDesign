//
//  CartListTableViewCell.swift
//  iosPos
//
//  Created by resolutesolutions on 14/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

class CartListTableViewCell: UITableViewCell {

    @IBOutlet weak var viewCart: UIView!
    @IBOutlet weak var btnModifier: UIButton!
    @IBOutlet weak var btnDeleteCart: UIButton!
    @IBOutlet weak var btnPlusQty: UIButton!
    @IBOutlet weak var btnMinusQty: UIButton!
    @IBOutlet weak var btnQtyTitle: RSCartQtyTitleButton!
    
    @IBOutlet weak var lblItemName: RSCartTitleLable!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.viewCart.applyShadowDefault()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
