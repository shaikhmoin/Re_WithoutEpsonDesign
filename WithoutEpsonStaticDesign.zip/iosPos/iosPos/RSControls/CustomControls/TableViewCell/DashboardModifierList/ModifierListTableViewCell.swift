//
//  ModifierListTableViewCell.swift
//  iosPos
//
//  Created by resolutesolutions on 13/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

class ModifierListTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
