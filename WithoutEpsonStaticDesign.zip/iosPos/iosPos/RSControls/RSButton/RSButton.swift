//
//  RSButton.swift
//  iosPos
//
//  Created by resolutesolutions on 05/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit
import SwiftyJSON

class RSButton: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.backgroundColor = UIColor.white
        self.layer.cornerRadius = 10
        self.titleLabel?.font = UIFont.appFont_LatoBold_WithSize(60.0)
        self.titleLabel?.textColor = UIColor.black
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}

class RSDashboardButton: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.backgroundColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_LIGHT_COLOR)
        self.titleLabel?.adjustsFontSizeToFitWidth = true
        self.clipsToBounds = true
        self.titleLabel?.font = UIFont.appFont_LatoRegular_WithSize(16)
        self.titleLabel?.textColor = UIColor.white
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}

class RSDashboardCartTitleButton: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.backgroundColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_DARK_COLOR)
        self.titleLabel?.adjustsFontSizeToFitWidth = true
        self.clipsToBounds = true
        self.titleLabel?.font = UIFont.appFont_LatoBold_WithSize(12.0)
        self.titleLabel?.textColor = UIColor.white
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}

class RSDashboardItemsTitleButton: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.backgroundColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_LIGHT_COLOR)
        self.titleLabel?.adjustsFontSizeToFitWidth = true
        self.clipsToBounds = true
        self.titleLabel?.font = UIFont.appFont_LatoBold_WithSize(12.0)
        self.titleLabel?.textColor = UIColor.white
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}

class RSDashboardButtonWithoutCorner: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        self.backgroundColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_LIGHT_COLOR)
        self.titleLabel?.font = UIFont.appFont_LatoBold_WithSize(16.0)
        self.titleLabel?.textColor = UIColor.white
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}

class RSDashboardButtonrupees: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.backgroundColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_LIGHT_COLOR)
        self.titleLabel?.font = UIFont.appFont_LatoBold_WithSize(22.0)
        self.titleLabel?.textColor = UIColor.white
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}

class RSCartQtyTitleButton: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.titleLabel?.font = UIFont.appFont_LatoRegular_WithSize(12)
        self.titleLabel?.textColor = UIColor.black
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}

class RSCartQtyTitleBolButton: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.titleLabel?.font = UIFont.appFont_LatoBold_WithSize(20.0)
        self.titleLabel?.textColor = UIColor.black
        self.titleLabel?.textAlignment = NSTextAlignment.center
    }
}
