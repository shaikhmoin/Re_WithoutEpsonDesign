//
//  RSLable.swift
//  iosPos
//
//  Created by resolutesolutions on 05/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

class RSLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoRegular_WithSize(12.0)
        self.textColor = UIColor.black
        self.textAlignment = NSTextAlignment.center
    }
}

class RSCartTitleLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoBold_WithSize(10.0)
        self.textColor = UIColor.black
        self.textAlignment = NSTextAlignment.center
    }
}

class RSItemListLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoBold_WithSize(12.0)
        self.textColor = UIColor.white
        self.textAlignment = NSTextAlignment.center
        self.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    }
}

class RSItemListTitleLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoBold_WithSize(10.0)
        self.textColor = UIColor.black
        self.textAlignment = NSTextAlignment.center
    }
}

class RSCartModifierTitleLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoRegular_WithSize(10.0)
        self.textColor = UIColor(hexString: CONSTANTS.APP_PRIMARY_DARK_COLOR)
        self.textAlignment = NSTextAlignment.center
    }
}

class RSCartModifierLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoBold_WithSize(14.0)
        self.textColor = UIColor.black
        self.textAlignment = NSTextAlignment.center
    }
}

class RSModifierPopupDetailLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoRegular_WithSize(12.0)
        self.textColor = UIColor.black
    }
}

class RSCartPriceTitleLable: UILabel {
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        self.font = UIFont.appFont_LatoRegular_WithSize(14.0)
        self.textColor = UIColor.black
        self.textAlignment = NSTextAlignment.left
    }
}




