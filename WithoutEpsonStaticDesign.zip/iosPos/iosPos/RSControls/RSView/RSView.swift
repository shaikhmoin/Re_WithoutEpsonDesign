//
//  RSView.swift
//  iosPos
//
//  Created by resolutesolutions on 05/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

class RSView: UIView {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
         self.layer.borderWidth = 2.0
         self.layer.borderColor = UIColor.black.cgColor
         self.applyShadowDefault()
    }
}
