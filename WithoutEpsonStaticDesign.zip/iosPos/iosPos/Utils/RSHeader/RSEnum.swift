//
//  RSEnum.swift
//  iosPos
//
//  Created by resolutesolutions on 12/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

//MARK:- TEXTFIELD TYPE
enum RSTextFieldType: Int{
    case
    Normal,
    Name,
    Password,
    Email,
    LocatioID,
    FromDate,
    ToDate
}
