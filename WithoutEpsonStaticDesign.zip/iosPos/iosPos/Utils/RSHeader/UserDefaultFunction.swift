//
//  UserDefaultFunction.swift
//  iosPos
//
//  Created by resolutesolutions on 12/06/18.
//  Copyright © 2018 resolutesolution. All rights reserved.
//

import UIKit

class UserDefaultFunction: NSObject {
    
    class public func setCustomDictionary(dict: [String : String], key:String) {
        print(dict)
        let dictData = NSKeyedArchiver.archivedData(withRootObject: dict)
        UserDefaults.standard.set(dictData, forKey: key)
    }
    
    class public func getDictionary(forKey: String) -> [String : String]? {
        let dictData = UserDefaults.standard.object(forKey: forKey)
        let object = NSKeyedUnarchiver.unarchiveObject(with: (dictData as! NSData) as Data)
        return object as? [String : String]
    }
}
